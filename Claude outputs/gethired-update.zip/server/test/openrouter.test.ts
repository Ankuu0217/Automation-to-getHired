import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { OutreachEmailInput } from '@jobmail/shared';

vi.mock('../src/config/env', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../src/config/env')>();
  return { env: { ...actual.env, OPENROUTER_API_KEY: 'sk-or-test', OPENROUTER_MODELS: 'a/one:free,b/two:free,c/three:free' } };
});

import { candidateModels, generateEmailOR, resetOpenRouterState, runChain } from '../src/services/ai/openrouter';
import { draftQualityProblem, finalizeOutreachEmail } from '../src/services/ai/emailWriter';

const input: OutreachEmailInput = {
  extraction: { company: 'Finlo', role: 'React Developer', location: 'Remote', jdText: 'We need React and TypeScript.', hrName: 'Riya Shah' },
  match: { score: 80, matchedSkills: ['React', 'TypeScript'], gaps: [], angle: 'React dashboards' },
  profile: {
    fullName: 'Ankit Singh',
    headline: 'Full Stack Developer (MERN)',
    yearsExp: 1.5,
    skills: ['React', 'TypeScript', 'Node.js'],
    summary: 'MERN developer',
    resumeText: 'Built React dashboards',
    phone: '+91 90000 00000',
    links: { linkedin: 'https://linkedin.com/in/ankit', github: '', portfolio: '' },
    signature: '',
  },
  tone: 'formal',
};

const good = {
  subject: 'React Developer role - Ankit Singh',
  bodyText:
    "Hi Riya,\n\nSaw your post about the React Developer opening at Finlo. The dashboard rebuild you mentioned is close to what I've been doing, moving an admin panel to React and TypeScript.\n\n- Built reusable React components used across three internal tools\n- Worked with the backend team on Node.js APIs\n\nI've attached my resume. Would you be open to a quick call this week?",
};

type Reply = { status: number; body: unknown };
let replies: Record<string, Reply[]> = {};
let calls: string[] = [];

function mockFetch() {
  vi.stubGlobal('fetch', vi.fn(async (url: string, init?: RequestInit) => {
    if (url.endsWith('/models')) return new Response(JSON.stringify({ data: [] }), { status: 200 });
    const model = JSON.parse(String(init?.body)).model as string;
    calls.push(model);
    const r = replies[model]?.shift() ?? { status: 404, body: { error: { code: 404, message: 'No endpoints found' } } };
    return new Response(JSON.stringify(r.body), { status: r.status });
  }));
}
const ok = (obj: unknown): Reply => ({ status: 200, body: { choices: [{ message: { content: JSON.stringify(obj) } }] } });

beforeEach(() => {
  resetOpenRouterState();
  replies = {};
  calls = [];
  mockFetch();
});
afterEach(() => vi.unstubAllGlobals());

describe('OpenRouter model chain', () => {
  it('orders configured models first and ends with the free router', async () => {
    expect(await candidateModels('text')).toEqual(['a/one:free', 'b/two:free', 'c/three:free', 'openrouter/free']);
  });

  it('fails over: 429 → bad JSON → success, and benches the rate-limited model', async () => {
    replies['a/one:free'] = [{ status: 429, body: { error: { code: 429, message: 'Rate limit exceeded' } } }];
    replies['b/two:free'] = [{ status: 200, body: { choices: [{ message: { content: 'sorry, cannot help' } }] } }];
    replies['c/three:free'] = [ok(good)];
    const draft = await generateEmailOR(input);
    expect(draft.model).toBe('c/three:free');
    expect(calls).toEqual(['a/one:free', 'b/two:free', 'c/three:free']);
    expect(await candidateModels('text')).not.toContain('a/one:free');
  });

  it('skips a robotic draft for a better one', async () => {
    replies['a/one:free'] = [ok({ subject: 'Job', bodyText: 'Dear Sir, I hope this finds you well. I am writing to express my keen interest.' })];
    replies['b/two:free'] = [ok(good)];
    const draft = await generateEmailOR(input);
    expect(draft.model).toBe('b/two:free');
  });

  it('reads JSON inside <think> blocks and code fences', async () => {
    replies['a/one:free'] = [{ status: 200, body: { choices: [{ message: { content: '<think>{"x":1}</think>```json\n{"n": 7}\n```' } }] } }];
    const { value } = await runChain({ label: 't', kind: 'text', parts: [{ type: 'text', text: 'x' }], parse: (r) => JSON.parse(r.replace(/<think>[\s\S]*?<\/think>/, '').replace(/```(json)?/g, '')) as { n: number } });
    expect(value.n).toBe(7);
  });

  it('stops immediately when the account daily free quota is used up', async () => {
    replies['a/one:free'] = [{ status: 429, body: { error: { code: 429, message: 'Rate limit exceeded: free-models-per-day' } } }];
    await expect(generateEmailOR(input)).rejects.toThrow();
    expect(calls).toEqual(['a/one:free']);
    await expect(generateEmailOR(input)).rejects.toThrow(/daily free quota/);
    expect(calls).toHaveLength(1);
  });
});

describe('email finishing pass', () => {
  it('removes AI tells, strips a model signature and appends the real one', () => {
    const out = finalizeOutreachEmail(
      {
        subject: 'Subject: React Developer role — Ankit Singh!',
        bodyText:
          "Hi Riya,\n\nI hope this email finds you well. Saw your post about the React role at Finlo — it lines up with my work! I utilized React daily.\n\nWould you be open to a quick call?\n\nBest regards,\nAnkit Singh\n+91 1111",
      },
      input,
    );
    expect(out.subject).toBe('React Developer role - Ankit Singh');
    expect(out.bodyText).not.toMatch(/—|!|hope this email|utilized/);
    expect(out.bodyText).toContain('I used React daily.');
    expect(out.bodyText.endsWith('Best regards,\nAnkit Singh\n+91 90000 00000\nlinkedin.com/in/ankit')).toBe(true);
    expect(out.bodyText.match(/Best regards/g)).toHaveLength(1);
  });

  it('keeps hyphens in date ranges', () => {
    const out = finalizeOutreachEmail({ subject: 's', bodyText: 'Hi Riya,\n\nAt Paytrail (2023–2024) I built dashboards.' }, input);
    expect(out.bodyText).toContain('(2023-2024)');
  });

  it('quality gate accepts a real draft and rejects placeholders / missing company', () => {
    expect(draftQualityProblem(good, input)).toBeNull();
    expect(draftQualityProblem({ subject: 's', bodyText: `${good.bodyText.replace(/Finlo/g, 'your company')}` }, input)).toMatch(/company/);
    expect(draftQualityProblem({ subject: 's', bodyText: `${good.bodyText} [Your Name]` }, input)).toMatch(/placeholder/);
  });
});
