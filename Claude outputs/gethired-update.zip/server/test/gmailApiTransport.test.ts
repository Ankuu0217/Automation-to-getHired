import http from 'node:http';
import type { AddressInfo } from 'node:net';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { google } from 'googleapis';
import { gmailApiTransport, GmailApiSendError, toGmailSendError } from '../src/services/gmail/apiTransport';
import { isPermanentSendError } from '../src/services/mailer';

/**
 * Outreach mail goes through the Gmail REST API over HTTPS (hosts like Render's
 * free plan block SMTP). A local stub stands in for googleapis.com so we check
 * the exact wire request: multipart media upload of the raw RFC 822 message,
 * Bearer auth, and that headers/threading/attachments survive.
 */

type Captured = { method: string; url: string; auth: string; contentType: string; body: string };
let captured: Captured[] = [];
let nextStatus = 200;
let nextBody: unknown = { id: 'm1', threadId: 't1', labelIds: ['SENT'] };
let server: http.Server;
let rootUrl = '';

beforeAll(async () => {
  server = http.createServer((req, res) => {
    const chunks: Buffer[] = [];
    req.on('data', (c: Buffer) => chunks.push(c));
    req.on('end', () => {
      captured.push({
        method: req.method ?? '',
        url: req.url ?? '',
        auth: String(req.headers.authorization ?? ''),
        contentType: String(req.headers['content-type'] ?? ''),
        body: Buffer.concat(chunks).toString('utf8'),
      });
      res.writeHead(nextStatus, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(nextBody));
    });
  });
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', () => r()));
  rootUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}/`;
});

afterAll(() => new Promise<void>((r) => server.close(() => r())));

function client() {
  const c = new google.auth.OAuth2('cid', 'secret', 'http://localhost/cb');
  c.setCredentials({ access_token: 'ya29.test-token', refresh_token: 'rt', expiry_date: Date.now() + 3600_000 });
  return c;
}

describe('gmailApiTransport', () => {
  it('uploads the raw MIME (headers, threading, attachment) with Bearer auth over HTTPS API', async () => {
    captured = [];
    nextStatus = 200;
    nextBody = { id: 'm1', threadId: 't1' };
    const t = gmailApiTransport(client(), { rootUrl });
    const pdf = Buffer.from('%PDF-1.4 resume bytes');
    const info = await t.sendMail({
      from: '"Ankit Singh" <ankit@gmail.com>',
      to: 'hr@acme.com',
      subject: 'Application: React Developer',
      text: 'Hello Priya',
      html: '<p>Hello Priya</p><img src="https://api.example.com/api/t/o/abc/0.png">',
      inReplyTo: '<prev@gethired>',
      references: '<prev@gethired>',
      attachments: [{ filename: 'Ankit_Singh_Resume.pdf', content: pdf, contentType: 'application/pdf' }],
    });

    expect(captured).toHaveLength(1);
    const req = captured[0];
    expect(req.method).toBe('POST');
    expect(req.url).toMatch(/^\/upload\/gmail\/v1\/users\/me\/messages\/send\?.*uploadType=multipart/);
    expect(req.auth).toBe('Bearer ya29.test-token');
    expect(req.contentType).toMatch(/^multipart\/related/);
    expect(req.body).toMatch(/content-type: message\/rfc822/i);
    expect(req.body).toMatch(/^To: hr@acme\.com/m);
    expect(req.body).toMatch(/^Subject: Application: React Developer/m);
    expect(req.body).toMatch(/^In-Reply-To: <prev@gethired>/m);
    expect(req.body).toMatch(/^References: <prev@gethired>/m);
    expect(req.body).toContain('filename=Ankit_Singh_Resume.pdf');
    expect(req.body).toContain(pdf.toString('base64'));
    // Message-ID is ours (stored for follow-up threading) and is in the MIME.
    expect(info.messageId).toMatch(/^<.+@.+>$/);
    expect(req.body).toContain(`Message-ID: ${info.messageId}`);
  });

  it('maps Gmail API errors onto the send pipeline semantics', async () => {
    const t = gmailApiTransport(client(), { rootUrl });
    const send = () => t.sendMail({ from: 'a@b.com', to: 'x@y.com', subject: 's', text: 't' });

    nextStatus = 400;
    nextBody = { error: { code: 400, message: 'Invalid To header', errors: [{ reason: 'invalidArgument' }] } };
    const bad = await send().catch((e) => e);
    expect(bad).toBeInstanceOf(GmailApiSendError);
    expect(isPermanentSendError(bad)).toBe(true); // bounce, no retry

    nextStatus = 401;
    nextBody = { error: { code: 401, message: 'Invalid Credentials', errors: [{ reason: 'authError' }] } };
    const auth = await send().catch((e) => e);
    expect(auth.code).toBe('EAUTH'); // → mark Gmail for reconnect
    expect(isPermanentSendError(auth)).toBe(false);

    nextStatus = 429;
    nextBody = { error: { code: 429, message: 'User-rate limit exceeded', errors: [{ reason: 'rateLimitExceeded' }] } };
    const rate = await send().catch((e) => e);
    expect(rate.code).toBeUndefined();
    expect(isPermanentSendError(rate)).toBe(false); // transient → retry
  });

  it('treats 403 quota/rate as transient but other 403s as a dead grant', () => {
    const quota = toGmailSendError({ response: { status: 403, data: { error: { message: 'Daily sending quota exceeded', errors: [{ reason: 'dailyLimitExceeded' }] } } } });
    expect(quota.code).toBeUndefined();
    expect(isPermanentSendError(quota)).toBe(false);
    const scope = toGmailSendError({ response: { status: 403, data: { error: { message: 'Insufficient Permission', errors: [{ reason: 'insufficientPermissions' }] } } } });
    expect(scope.code).toBe('ESCOPE');
    const other = toGmailSendError({ response: { status: 403, data: { error: { message: 'Forbidden' } } } });
    expect(other.code).toBe('EAUTH');
  });

  it('flags a disabled Gmail API as a server setup problem', () => {
    const disabled = toGmailSendError({
      response: { status: 403, data: { error: { message: 'Gmail API has not been used in project 123 before or it is disabled.', errors: [{ reason: 'accessNotConfigured' }] } } },
    });
    expect(disabled.code).toBe('EAPI_DISABLED');
    expect(isPermanentSendError(disabled)).toBe(false);
  });
});
